package Restclient;

import java.io.IOException;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.HttpResponse;


public class RestClient {

    public CloseableHttpResponse get(String url) throws IOException {

        CloseableHttpClient httpClient =  HttpClients.createDefault();
        HttpGet httpget = new HttpGet(url);
        CloseableHttpResponse closeableHttpResponse = httpClient.execute(httpget); //Hit the url to get response
        closeableHttpResponse.getStatusLine().getStatusCode();
        return closeableHttpResponse;
    }
}
