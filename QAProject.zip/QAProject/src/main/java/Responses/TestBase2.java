package Responses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class TestBase2 {

    public int RESPONSE_STATUS_CODE_200 = 200;
    public int RESPONSE_STATUS_CODE_500 = 500;
    public int RESPONSE_STATUS_CODE_400 = 400;
    public int RESPONSE_STATUS_CODE_401 = 401;
    public int RESPONSE_STATUS_CODE_201 = 201;

    public Properties prop2;

    public TestBase2(){

        try {
            prop2 = new Properties();
            FileInputStream ip = new FileInputStream("C:\\eclipse-workspace\\QAProject\\src\\main\\java\\Config\\config2.properties");
            prop2.load(ip);
        }

        catch (FileNotFoundException e){
            e.printStackTrace();
        }

        catch (IOException e){
            e.printStackTrace();
        }
    }
}
