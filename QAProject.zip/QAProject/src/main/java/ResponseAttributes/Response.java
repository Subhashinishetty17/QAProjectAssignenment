package ResponseAttributes;

import java.io.IOException;
import org.json.JSONObject;
import org.junit.Assert;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import Responses.TestBase;
import Responses.TestBase2;
import Restclient.RestClient;
import util.TestUtil;

public class Response extends TestBase{

	TestBase testBase;
    RestClient restClient;
    CloseableHttpResponse closeableHttpResponse;
    String serviceurl;
    String apiURL;
    String url;
  
	public void setUp() throws IOException{
	    testBase = new TestBase();
	    serviceurl = prop.getProperty("URL");
	    apiURL = prop.getProperty("serviceURL");
	    url = serviceurl + apiURL;
	    restClient = new RestClient();
		closeableHttpResponse = restClient.get(url);
	}
	
	public int getTest() throws IOException {
		setUp();
		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		return statusCode;     
	 }
	        	
    public String getPromotionId(int value) throws IOException {
    	setUp();
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);      
		String promotionId=TestUtil.getValueByJPath(responseJson,"/promotions["+value+"]/promotionId");
		Assert.assertNotNull(promotionId);
		return promotionId;
    }  
    public String getorderId(int value) throws IOException {
    	setUp();
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);      
		String orderId=TestUtil.getValueByJPath(responseJson,"/promotions["+value+"]/orderId");
		Assert.assertNotNull(orderId);
		return orderId;
    }
    
    public String getpromoArea(int value) throws IOException {
    	setUp();   
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);    
	    String promoAreatext = TestUtil.getValueByJPath(responseJson, "/promotions["+value+"]/promoArea["+0+"]");
        Assert.assertNotNull(promoAreatext);
       	return promoAreatext;
    }
    
    public String getshowPrice(int value) throws IOException {
    	setUp();   
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);    
		String showPrice = TestUtil.getValueByJPath(responseJson, "/promotions["+value+"]/showPrice");
        Assert.assertNotNull(showPrice);
       	return showPrice;	
    }

    public String getshowText(int value) throws IOException {
    	setUp();   
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);    
		String showText = TestUtil.getValueByJPath(responseJson, "/promotions["+value+"]/showText");
        Assert.assertNotNull(showText);
       	return showText;	
    }
    public String getlocalizedTexts(int value) throws IOException {
    	setUp();   
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		JSONObject responseJson = new JSONObject(responseString);    
		String localizedTexts = TestUtil.getValueByJPath(responseJson, "/promotions["+value+"]/localizedTexts");
        System.out.println("localizedTexts " + localizedTexts);
        Assert.assertNotNull(localizedTexts);
       	return localizedTexts;	
    }
    
    public String getprogramType() throws IOException {
	setUp();   
	String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
	JSONObject responseJson = new JSONObject(responseString);    
	String properties = TestUtil.getValueByJPath(responseJson, "/promotions["+0+"]/properties["+0+"]/programType");
	Assert.assertNotNull(properties);
	return properties;
    }
    
                    
}
 

