package ResponseAttributes;

import java.io.IOException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import Responses.TestBase2;
import Restclient.RestClient;

public class ResponseInv extends TestBase2{
	TestBase2 testBaseinvalid;
    RestClient restClient;
    CloseableHttpResponse closeableHttpResponse;
    String serviceurl;
    String apiURL;
    String url;
    
    public int responseinvalid() throws IOException {
    	testBaseinvalid = new TestBase2();
	    serviceurl = prop2.getProperty("URL");
	    apiURL = prop2.getProperty("serviceURL");
	    url = serviceurl + apiURL;
	    System.out.println("URL:-->" +url);
	    restClient = new RestClient();
		closeableHttpResponse = restClient.get(url);
		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
        System.out.println("InvalidStatus Code:---> "+statusCode);
        String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
        System.out.println("Invalid Response:---> "+responseString);   
		return statusCode;  
        }
}
