package StepDefination;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.io.IOException;



import ResponseAttributes.Response;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Responseproperty {
	
	Response response;
	@Given("The JSON response")
	public void the_json_response() {
		System.out.println("The JSON response for validating the response parameters");
	}
	@When("The JSON response is successful")
	public void the_json_response_is_successful() {
		System.out.println("The JSON response is successful");
	}
	@Then("The {int} PromotionID {string} should be present")
	public void the_promotion_id_should_be_present(Integer value, String promotionID) throws IOException {
		response = new Response();
		assertEquals(promotionID, response.getPromotionId(value));
		System.out.println("The JSON Response has promotionID:-->" +response.getPromotionId(value));
	}	
	
	@Then("The {int} orderId {int} should be present")
	public void the_order_id_should_be_present(Integer value , Integer orderId) throws IOException {
		response = new Response();
		String orderIds = orderId.toString();
		assertEquals(orderIds,response.getorderId(value));
		System.out.println("The JSON Response has orderId:-->" +response.getorderId(value));
	}
	
	@Then("The {int} promoArea {string} should be present")
	public void the_promo_area_should_be_present(Integer value, String promoArea) throws IOException {
		response = new Response();
		assertEquals(promoArea,response.getpromoArea(value));
		System.out.println("The JSON Response has orderId:-->" +response.getpromoArea(value));
	}
	
	@Then("The {int} showPrice {string} should be present")
	public void the_show_price_should_be_present(Integer value, String showPrice) throws IOException {
		response = new Response();
		assertEquals(showPrice,response.getshowPrice(value));
		System.out.println("The JSON Response has orderId:-->" +response.getshowPrice(value));
	}

	@Then("The {int} showText {string} should be present")
	public void the_show_text_should_be_present(Integer value, String showText) throws IOException {
		response = new Response();
		assertEquals(showText,response.getshowText(value));
		System.out.println("The JSON Response has orderId:-->" +response.getshowText(value));
	}
}
