package StepDefination;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.testng.Assert;

import ResponseAttributes.Response;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class JsonResponse {

	
	Response response;
	@Given("The JSON request")
	public void the_json_request() {
		System.out.println("The JSON request");
	}

	@When("^The response is received$")
	public void t_he_response_is_received() {
		System.out.println("The Response is received");
	}

	@Then("The HTTP status code should be {int}")
	public void the_http_status_code_should_be(Integer ResponseCode) throws IOException {
	    System.out.println("Display the HTTP status code: " +ResponseCode);
		response = new Response();
		response.setUp();
		assertEquals(ResponseCode, response.getTest());
	}
}
