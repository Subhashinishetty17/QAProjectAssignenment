package StepDefination;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import ResponseAttributes.ResponseInv;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Responseinvalid {
	
	ResponseInv responseinvalid;
	@Given("The JSON invalid request")
	public void the_json_invalid_request() {
		System.out.println("Invalid Json Resquest");
	}

	@When("The JSON response is invalid")
	public void the_json_response_is_invalid() {
		System.out.println("The Json response is invalid");
	}

	@Then("The status code should be {int}")
	public void the_status_code_should_be(Integer ResponseCode) throws IOException {
		responseinvalid= new ResponseInv();
		assertEquals(ResponseCode, responseinvalid.responseinvalid());
	}

}
