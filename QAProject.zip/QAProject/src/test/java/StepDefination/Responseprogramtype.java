package StepDefination;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import ResponseAttributes.Response;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Responseprogramtype {
	Response response;
	@When("The promotionId is {string}")
	public void the_promotion_id_is(String promotionId) {
		System.out.println("The promotionId is :" +promotionId);
	}

	@Then("The programType should be {string}")
	public void the_program_type_should_be(String programType) throws IOException {
		System.out.println("The promotionId in the Response is :-->" +programType);
		response = new Response();
		assertEquals(programType,response.getprogramType());
		System.out.println("The programType in the Response file is :-->" +response.getprogramType());
	}
}
